/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Cyrsova/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[37];
    char stringdata0[817];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 8), // "MakePlot"
QT_MOC_LITERAL(2, 20, 0), // ""
QT_MOC_LITERAL(3, 21, 5), // "Clear"
QT_MOC_LITERAL(4, 27, 10), // "UpdatePlot"
QT_MOC_LITERAL(5, 38, 20), // "TabWidgetPointUpdate"
QT_MOC_LITERAL(6, 59, 13), // "InfoTabUpdate"
QT_MOC_LITERAL(7, 73, 31), // "on_pushButton_add_point_clicked"
QT_MOC_LITERAL(8, 105, 20), // "on_plotDoubleClicked"
QT_MOC_LITERAL(9, 126, 12), // "QMouseEvent*"
QT_MOC_LITERAL(10, 139, 5), // "event"
QT_MOC_LITERAL(11, 145, 16), // "on_plotMouseMove"
QT_MOC_LITERAL(12, 162, 33), // "on_pushButton_clear_graph_cli..."
QT_MOC_LITERAL(13, 196, 17), // "on_plotMousePress"
QT_MOC_LITERAL(14, 214, 4), // "Swap"
QT_MOC_LITERAL(15, 219, 42), // "on_checkBox_connect_two_lines..."
QT_MOC_LITERAL(16, 262, 4), // "arg1"
QT_MOC_LITERAL(17, 267, 34), // "on_checkBox_fill_area_stateCh..."
QT_MOC_LITERAL(18, 302, 37), // "on_checkBox_built_figure_stat..."
QT_MOC_LITERAL(19, 340, 40), // "on_checkBox_buil_circle_out_s..."
QT_MOC_LITERAL(20, 381, 38), // "on_listWidget_points_itemDoub..."
QT_MOC_LITERAL(21, 420, 16), // "QListWidgetItem*"
QT_MOC_LITERAL(22, 437, 4), // "item"
QT_MOC_LITERAL(23, 442, 36), // "on_checkBox_point_cross_state..."
QT_MOC_LITERAL(24, 479, 26), // "on_tabWidget_tabBarClicked"
QT_MOC_LITERAL(25, 506, 5), // "index"
QT_MOC_LITERAL(26, 512, 34), // "on_pushButton_save_to_file_cl..."
QT_MOC_LITERAL(27, 547, 36), // "on_pushButton_read_from_file_..."
QT_MOC_LITERAL(28, 584, 23), // "on_actionRead_triggered"
QT_MOC_LITERAL(29, 608, 23), // "on_actionSave_triggered"
QT_MOC_LITERAL(30, 632, 24), // "on_actionReset_triggered"
QT_MOC_LITERAL(31, 657, 33), // "on_pushButton_chage_point_cli..."
QT_MOC_LITERAL(32, 691, 32), // "on_listWidget_points_itemClicked"
QT_MOC_LITERAL(33, 724, 39), // "on_checkBox_buil_circle_in_st..."
QT_MOC_LITERAL(34, 764, 28), // "on_pushButton_make2d_clicked"
QT_MOC_LITERAL(35, 793, 10), // "closeEvent"
QT_MOC_LITERAL(36, 804, 12) // "QCloseEvent*"

    },
    "MainWindow\0MakePlot\0\0Clear\0UpdatePlot\0"
    "TabWidgetPointUpdate\0InfoTabUpdate\0"
    "on_pushButton_add_point_clicked\0"
    "on_plotDoubleClicked\0QMouseEvent*\0"
    "event\0on_plotMouseMove\0"
    "on_pushButton_clear_graph_clicked\0"
    "on_plotMousePress\0Swap\0"
    "on_checkBox_connect_two_lines_stateChanged\0"
    "arg1\0on_checkBox_fill_area_stateChanged\0"
    "on_checkBox_built_figure_stateChanged\0"
    "on_checkBox_buil_circle_out_stateChanged\0"
    "on_listWidget_points_itemDoubleClicked\0"
    "QListWidgetItem*\0item\0"
    "on_checkBox_point_cross_stateChanged\0"
    "on_tabWidget_tabBarClicked\0index\0"
    "on_pushButton_save_to_file_clicked\0"
    "on_pushButton_read_from_file_clicked\0"
    "on_actionRead_triggered\0on_actionSave_triggered\0"
    "on_actionReset_triggered\0"
    "on_pushButton_chage_point_clicked\0"
    "on_listWidget_points_itemClicked\0"
    "on_checkBox_buil_circle_in_stateChanged\0"
    "on_pushButton_make2d_clicked\0closeEvent\0"
    "QCloseEvent*"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  154,    2, 0x08 /* Private */,
       3,    0,  155,    2, 0x08 /* Private */,
       4,    0,  156,    2, 0x08 /* Private */,
       5,    0,  157,    2, 0x08 /* Private */,
       6,    0,  158,    2, 0x08 /* Private */,
       7,    0,  159,    2, 0x08 /* Private */,
       8,    1,  160,    2, 0x08 /* Private */,
      11,    1,  163,    2, 0x08 /* Private */,
      12,    0,  166,    2, 0x08 /* Private */,
      13,    1,  167,    2, 0x08 /* Private */,
      14,    2,  170,    2, 0x08 /* Private */,
      15,    1,  175,    2, 0x08 /* Private */,
      17,    1,  178,    2, 0x08 /* Private */,
      18,    1,  181,    2, 0x08 /* Private */,
      19,    1,  184,    2, 0x08 /* Private */,
      20,    1,  187,    2, 0x08 /* Private */,
      23,    1,  190,    2, 0x08 /* Private */,
      24,    1,  193,    2, 0x08 /* Private */,
      26,    0,  196,    2, 0x08 /* Private */,
      27,    0,  197,    2, 0x08 /* Private */,
      28,    0,  198,    2, 0x08 /* Private */,
      29,    0,  199,    2, 0x08 /* Private */,
      30,    0,  200,    2, 0x08 /* Private */,
      31,    0,  201,    2, 0x08 /* Private */,
      32,    1,  202,    2, 0x08 /* Private */,
      33,    1,  205,    2, 0x08 /* Private */,
      34,    0,  208,    2, 0x08 /* Private */,
      35,    1,  209,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void, 0x80000000 | 9,    2,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,    2,
    QMetaType::Void, QMetaType::Double, QMetaType::Double,    2,    2,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   25,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 36,   10,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->MakePlot(); break;
        case 1: _t->Clear(); break;
        case 2: _t->UpdatePlot(); break;
        case 3: _t->TabWidgetPointUpdate(); break;
        case 4: _t->InfoTabUpdate(); break;
        case 5: _t->on_pushButton_add_point_clicked(); break;
        case 6: _t->on_plotDoubleClicked((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 7: _t->on_plotMouseMove((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 8: _t->on_pushButton_clear_graph_clicked(); break;
        case 9: _t->on_plotMousePress((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 10: _t->Swap((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 11: _t->on_checkBox_connect_two_lines_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->on_checkBox_fill_area_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->on_checkBox_built_figure_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_checkBox_buil_circle_out_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_listWidget_points_itemDoubleClicked((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 16: _t->on_checkBox_point_cross_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->on_tabWidget_tabBarClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->on_pushButton_save_to_file_clicked(); break;
        case 19: _t->on_pushButton_read_from_file_clicked(); break;
        case 20: _t->on_actionRead_triggered(); break;
        case 21: _t->on_actionSave_triggered(); break;
        case 22: _t->on_actionReset_triggered(); break;
        case 23: _t->on_pushButton_chage_point_clicked(); break;
        case 24: _t->on_listWidget_points_itemClicked((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 25: _t->on_checkBox_buil_circle_in_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: _t->on_pushButton_make2d_clicked(); break;
        case 27: _t->closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 28;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
